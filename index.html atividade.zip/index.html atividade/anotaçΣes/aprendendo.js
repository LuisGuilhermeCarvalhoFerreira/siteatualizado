// uma linguagem não typada  
  
"use strict"
window.alert("ola mundo"); 
// isso é um dos equivalentes do escreva 
// uso de ; para terminar um comando  
var nome
// variavel nome 
var datadenascimento, nota1 , nota2 , nota3 , result
nome=prompt("Escreva seu nome");
window.alert(nome);
// +,-,*,/, 
// && é comercial = 
// igual a algo == / se eu colocar = é atribuição 
// === favor e tipo  se exemplo se algo é igual a isso tipo nome=h1  
// float = real 
// string= cadeia
// if se 
// else if senão se
// else senão 
datadenascimento=prompt("Escreva sua data de nascimento");
window.alert(datadenascimento-2024);

nota1=parseFloat(prompt("escreva uma nota1 "))
nota2=parseFloat(prompt("escreva nota 2"))
nota3=parseFloat(prompt("escreva sua nota 3")) 

window.alert("sua nota total é"+ nota1+nota2+nota3)

result=parseFloat(prompt(nota1+nota2+nota3))
